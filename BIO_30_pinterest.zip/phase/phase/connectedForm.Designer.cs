﻿
namespace phase
{
    partial class connectedForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.text_cat = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmb_PinCreator = new System.Windows.Forms.ComboBox();
            this.search1 = new System.Windows.Forms.Button();
            this.cmb_pinId = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.text_pinCat = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.text_pinType = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cmb_userID = new System.Windows.Forms.ComboBox();
            this.insert = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.proc_userID = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.proc_userFav = new System.Windows.Forms.TextBox();
            this.proc_search = new System.Windows.Forms.Button();
            this.sys_pinType = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.sys_search = new System.Windows.Forms.Button();
            this.sys_catOut = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Category";
            // 
            // text_cat
            // 
            this.text_cat.Location = new System.Drawing.Point(74, 55);
            this.text_cat.Name = "text_cat";
            this.text_cat.Size = new System.Drawing.Size(100, 20);
            this.text_cat.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(225, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "owner email";
            // 
            // cmb_PinCreator
            // 
            this.cmb_PinCreator.FormattingEnabled = true;
            this.cmb_PinCreator.Location = new System.Drawing.Point(294, 52);
            this.cmb_PinCreator.Name = "cmb_PinCreator";
            this.cmb_PinCreator.Size = new System.Drawing.Size(121, 21);
            this.cmb_PinCreator.TabIndex = 3;
            // 
            // search1
            // 
            this.search1.Location = new System.Drawing.Point(780, 50);
            this.search1.Name = "search1";
            this.search1.Size = new System.Drawing.Size(75, 23);
            this.search1.TabIndex = 4;
            this.search1.Text = "search";
            this.search1.UseVisualStyleBackColor = true;
            this.search1.Click += new System.EventHandler(this.search1_Click);
            // 
            // cmb_pinId
            // 
            this.cmb_pinId.FormattingEnabled = true;
            this.cmb_pinId.Location = new System.Drawing.Point(53, 136);
            this.cmb_pinId.Name = "cmb_pinId";
            this.cmb_pinId.Size = new System.Drawing.Size(121, 21);
            this.cmb_pinId.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 141);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "pin_id";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(200, 141);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "category";
            // 
            // text_pinCat
            // 
            this.text_pinCat.Location = new System.Drawing.Point(254, 138);
            this.text_pinCat.Name = "text_pinCat";
            this.text_pinCat.Size = new System.Drawing.Size(100, 20);
            this.text_pinCat.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(387, 141);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "pin_type";
            // 
            // text_pinType
            // 
            this.text_pinType.Location = new System.Drawing.Point(440, 138);
            this.text_pinType.Name = "text_pinType";
            this.text_pinType.Size = new System.Drawing.Size(100, 20);
            this.text_pinType.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(560, 141);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "user_id";
            // 
            // cmb_userID
            // 
            this.cmb_userID.FormattingEnabled = true;
            this.cmb_userID.Location = new System.Drawing.Point(607, 138);
            this.cmb_userID.Name = "cmb_userID";
            this.cmb_userID.Size = new System.Drawing.Size(121, 21);
            this.cmb_userID.TabIndex = 12;
            // 
            // insert
            // 
            this.insert.Location = new System.Drawing.Point(780, 136);
            this.insert.Name = "insert";
            this.insert.Size = new System.Drawing.Size(75, 23);
            this.insert.TabIndex = 13;
            this.insert.Text = "insert";
            this.insert.UseVisualStyleBackColor = true;
            this.insert.Click += new System.EventHandler(this.insert_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 242);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "user_id";
            // 
            // proc_userID
            // 
            this.proc_userID.FormattingEnabled = true;
            this.proc_userID.Location = new System.Drawing.Point(74, 238);
            this.proc_userID.Name = "proc_userID";
            this.proc_userID.Size = new System.Drawing.Size(121, 21);
            this.proc_userID.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(241, 238);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(42, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "favorite";
            // 
            // proc_userFav
            // 
            this.proc_userFav.Location = new System.Drawing.Point(289, 235);
            this.proc_userFav.Name = "proc_userFav";
            this.proc_userFav.Size = new System.Drawing.Size(100, 20);
            this.proc_userFav.TabIndex = 17;
            // 
            // proc_search
            // 
            this.proc_search.Location = new System.Drawing.Point(780, 233);
            this.proc_search.Name = "proc_search";
            this.proc_search.Size = new System.Drawing.Size(75, 23);
            this.proc_search.TabIndex = 18;
            this.proc_search.Text = "search";
            this.proc_search.UseVisualStyleBackColor = true;
            this.proc_search.Click += new System.EventHandler(this.proc_search_Click);
            // 
            // sys_pinType
            // 
            this.sys_pinType.Location = new System.Drawing.Point(74, 314);
            this.sys_pinType.Name = "sys_pinType";
            this.sys_pinType.Size = new System.Drawing.Size(100, 20);
            this.sys_pinType.TabIndex = 22;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 318);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 13);
            this.label9.TabIndex = 21;
            this.label9.Text = "pin_type";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(240, 318);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 13);
            this.label10.TabIndex = 19;
            this.label10.Text = "category";
            // 
            // sys_search
            // 
            this.sys_search.Location = new System.Drawing.Point(780, 312);
            this.sys_search.Name = "sys_search";
            this.sys_search.Size = new System.Drawing.Size(75, 23);
            this.sys_search.TabIndex = 23;
            this.sys_search.Text = "search";
            this.sys_search.UseVisualStyleBackColor = true;
            this.sys_search.Click += new System.EventHandler(this.sys_search_Click);
            // 
            // sys_catOut
            // 
            this.sys_catOut.FormattingEnabled = true;
            this.sys_catOut.Location = new System.Drawing.Point(294, 314);
            this.sys_catOut.Name = "sys_catOut";
            this.sys_catOut.Size = new System.Drawing.Size(121, 21);
            this.sys_catOut.TabIndex = 24;
            // 
            // connectedForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(887, 450);
            this.Controls.Add(this.sys_catOut);
            this.Controls.Add(this.sys_search);
            this.Controls.Add(this.sys_pinType);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.proc_search);
            this.Controls.Add(this.proc_userFav);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.proc_userID);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.insert);
            this.Controls.Add(this.cmb_userID);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.text_pinType);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.text_pinCat);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmb_pinId);
            this.Controls.Add(this.search1);
            this.Controls.Add(this.cmb_PinCreator);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.text_cat);
            this.Controls.Add(this.label1);
            this.Name = "connectedForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox text_cat;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmb_PinCreator;
        private System.Windows.Forms.Button search1;
        private System.Windows.Forms.ComboBox cmb_pinId;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox text_pinCat;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox text_pinType;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmb_userID;
        private System.Windows.Forms.Button insert;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox proc_userID;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox proc_userFav;
        private System.Windows.Forms.Button proc_search;
        private System.Windows.Forms.TextBox sys_pinType;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button sys_search;
        private System.Windows.Forms.ComboBox sys_catOut;
    }
}

